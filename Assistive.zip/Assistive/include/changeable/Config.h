#ifndef _CONFIG_H
#define _CONFIG_H

#if defined(_ASSISTIVETOUCH_H)
// 定义默认启动工具的数量
const int defauleToolsNum = 0;
#endif

#if defined(_FUNCTIONMODULEFACTORY_H)
// 定义预留vector<FunctionModule*> m_module的大小
const int defauleReserveSpace = 10;
#endif

#if defined(_NORMALMAINFORM_H)
// 定义normalmainform圆的半径
const int defauleCircleSize = 150;
const int defaulePushButtonHalfSize = 35;
#endif

#endif // _CONFIG_H
