#ifndef _HOMEMAINFORM_H
#define _HOMEMAINFORM_H

#include <QtGui>


namespace Ui {
class HomeForm;
}

class NormalMainForm;

class HomeMainForm: public QDialog{
	
	Q_OBJECT

public:
	explicit HomeMainForm(NormalMainForm* nMF, QWidget* parent = 0);
	~HomeMainForm();
	void Show(void);
	
private:
	// ��дwidget������¼�
    void mousePressEvent(QMouseEvent* event);
    void mouseReleaseEvent(QMouseEvent* event);
	void mouseMoveEvent(QMouseEvent* event);
	// qtdesigner ����ͼƬ��Ҫ��дpaintEvent�¼�
	void paintEvent(QPaintEvent *);

	
private:
	void ShowNormalMainForm(void);
	
private:
	Ui::HomeForm* ui;
	NormalMainForm* m_normalMainForm;
	QTimer* m_timer;
	bool m_bDrag;
	int m_xOffset;
	int m_yOffset;
	int m_cx; 
	int m_cy;
};

#endif // _HOMEMAINFORM_H
