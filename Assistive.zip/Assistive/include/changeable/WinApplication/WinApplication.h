#ifndef _WINAPPLICATION_H
#define _WINAPPLICATION_H
#include <windows.h>
#include <QtGui>
#include <QApplication>

#include "changeable/Clipboard/Clipboard.h"

extern HWND hwndClipBoardViewer;

class FunctionModule;

class WinApplication:public QApplication  
{  
    Q_OBJECT  
public:  
    WinApplication(int argc,char *argv[]);  
    ~WinApplication(){}  
	void GetClipboard(FunctionModule* clb);
	
protected:  
    bool winEventFilter(MSG *message, long *result);  
	
private:
	Clipboard* m_clipboard;
};

inline void WinApplication::GetClipboard(FunctionModule* clb) {
		m_clipboard = (Clipboard*)clb;
}

#endif //_WINAPPLICATION_H