/********************************************************************************
** Form generated from reading UI file 'untitled.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef DEBUGMAINFORM_H
#define DEBUGMAINFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QAction *m_actionExit;
    QPushButton *m_clipboard;
    QPushButton *m_desktopbutton;
    QPushButton *m_backbutton;
    QPushButton *m_volume;
    QPushButton *m_bright;
    QPushButton *m1;
    QPushButton *m2;

    void setupUi(QWidget *Form)
    {
        int pushbuttonsize = 70;
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("AssistiveTouch"));
        //Form->resize(510, 328);
        Form->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background-color: rgb(0, 0, 0, 1);\n"
"}"));
        m_actionExit = new QAction(Form);
        m_actionExit->setObjectName(QString::fromUtf8("actionExit"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/home.png"), QSize(), QIcon::Normal, QIcon::Off);
        m_actionExit->setIcon(icon);
        m_clipboard = new QPushButton(Form);
        m_clipboard->setObjectName(QString::fromUtf8("m_clipboard"));
        m_clipboard->setGeometry(QRect(70, 30, pushbuttonsize, pushbuttonsize));
        m_clipboard->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background-color: rgb(111, 111, 111, 190);\n"
"	border-radius: 35px 35px 35px 35px;\n"
"}"));
        m_desktopbutton = new QPushButton(Form);
        m_desktopbutton->setObjectName(QString::fromUtf8("m_desktopbutton"));
        m_desktopbutton->setGeometry(QRect(210, 30, pushbuttonsize, pushbuttonsize));
        m_desktopbutton->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background-color: rgb(111, 111, 111, 190);\n"
"	border-radius: 35px 35px 35px 35px;\n"
"}"));
#if 1
        m_backbutton = new QPushButton(Form);
        m_backbutton->setObjectName(QString::fromUtf8("m_backbutton"));
        m_backbutton->setGeometry(QRect(190, 150, pushbuttonsize, pushbuttonsize));
        m_backbutton->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background-color: rgb(111, 111, 111, 190);\n"
"	border-radius: 35px 35px 35px 35px;\n"
"}"));
#endif
        m_volume = new QPushButton(Form);
        m_volume->setObjectName(QString::fromUtf8("m_volume"));
        m_volume->setGeometry(QRect(350, 100, pushbuttonsize, pushbuttonsize));
        m_volume->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background-color: rgb(111, 111, 111, 190);\n"
"	border-radius: 35px 35px 35px 35px;\n"
"}"));
        m_bright = new QPushButton(Form);
        m_bright->setObjectName(QString::fromUtf8("m_bright"));
        m_bright->setGeometry(QRect(70, 155, pushbuttonsize, pushbuttonsize));
        m_bright->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background-color: rgb(111, 111, 111, 190);\n"
"	border-radius: 35px 35px 35px 35px;\n"
"}"));

        m1 = new QPushButton(Form);
        m1->setObjectName(QString::fromUtf8("m1"));
        m1->setGeometry(QRect(70, 155, pushbuttonsize, pushbuttonsize));
        m1->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background-color: rgb(111, 111, 111, 190);\n"
"	border-radius: 35px 35px 35px 35px;\n"
"}"));
        m2 = new QPushButton(Form);
        m2->setObjectName(QString::fromUtf8("m1"));
        m2->setGeometry(QRect(70, 155, pushbuttonsize, pushbuttonsize));
        m2->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	background-color: rgb(111, 111, 111, 190);\n"
"	border-radius: 35px 35px 35px 35px;\n"
"}"));

        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QApplication::translate("Form", "Form", 0, QApplication::UnicodeUTF8));
        m_actionExit->setText(QApplication::translate("Form", "\351\200\200\345\207\272\347\250\213\345\272\217", 0, QApplication::UnicodeUTF8));
        m_clipboard->setText(QApplication::translate("Form", "clipboard", 0, QApplication::UnicodeUTF8));
        m_desktopbutton->setText(QApplication::translate("Form", "desktop", 0, QApplication::UnicodeUTF8));
        m_backbutton->setText(QApplication::translate("Form", "back", 0, QApplication::UnicodeUTF8));
        m_volume->setText(QApplication::translate("Form", "volume", 0, QApplication::UnicodeUTF8));
        m_bright->setText(QApplication::translate("Form", "bright", 0, QApplication::UnicodeUTF8));
        m1->setText(QApplication::translate("Form", "m1", 0, QApplication::UnicodeUTF8));
        m2->setText(QApplication::translate("Form", "m2", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // DEBUGMAINFORM_H
