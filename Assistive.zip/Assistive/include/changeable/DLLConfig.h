#ifndef _DLLCONFIG_H
#define _DLLCONFIG_H
#include <windows.h>


//typedef struct {
struct DLLConfig{
	// 动态库句柄
	//void* DLLHandle;
	HINSTANCE dllHandle;
	// 功能一
	void (*ModFun1)(void);
//} DLLConfig;
};
#endif // _DLLCONFIG_H
