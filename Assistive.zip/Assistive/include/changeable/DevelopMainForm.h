#ifndef _DEVELOPMAINFORM_H
#define _DEVELOPMAINFORM_H

class DevelopMainForm: public MainForm {
public:
	virtual void show(void);
};

#endif // _DEVELOPMAINFORM_H
