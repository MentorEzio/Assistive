#ifndef _BACKTODESKTOP_H
#define _BACKTODESKTOP_H

#include "changeless/NormalModule.h"

class BacktoDesktop: public NormalModule {
public:
	virtual void Start(void) {
		keybd_event(VK_RWIN,0,0,0);             		//����win��                        
		keybd_event(0x4D,0,0,0);                        //����m��                  
		keybd_event(0x4D,0,KEYEVENTF_KEYUP,0);          //�ɿ�m��
		keybd_event(VK_RWIN,0,KEYEVENTF_KEYUP,0);		//�ɿ�win��
	}
};

#endif // _BACKTODESKTOP_H