#ifndef _DEBUGTOOL_H
#define _DEBUGTOOL_H

#include "changeless/NormalModule.h"
#include "changeable/DLLConfig.h"
#include "debug/debuger.h"
#include <iostream>
using namespace std;

extern DLLConfig* dllManager;

class DebugTool: public NormalModule {
public:
	virtual void Start(void) {
		void (*print)(void);
		print = dllManager->ModFun1;
		DEBUG_NORMAL("开始调用print函数\n");
		print();
		
		DEBUG_NORMAL("debug 功能测试\n");
	}
};

#endif // _DEBUGTOOL_H
