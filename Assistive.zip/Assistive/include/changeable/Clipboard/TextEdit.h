#ifndef _TEXTEDIT_H
#define _TEXTEDIT_H

#include <QtGui>

namespace Ui{
    class TextEditForm;
}

class TextEdit: public QWidget {
public:
    TextEdit(QWidget* parent = nullptr);
    ~TextEdit();
    void ShowString(QString& str) const;
	
private:
	void closeEvent(QCloseEvent *event);

private:
    Ui::TextEditForm* ui;
};



#endif // _TEXTEDIT_H