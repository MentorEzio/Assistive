#ifndef _MYLISTWIDGETITEM_H
#define _MYLISTWIDGETITEM_H

#include <QtGui>

class MyListWidgetItem: public QListWidgetItem {
public:
    MyListWidgetItem(const QString& str, QListWidget* parent = nullptr);
    ~MyListWidgetItem();
    QString& GetString(void);
    
private:
    QString* m_clipboarddetail;
    static QFont m_itemfont;
};

#endif // _MYLISTWIDGETITEM_H