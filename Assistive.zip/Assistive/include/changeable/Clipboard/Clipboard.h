#ifndef _CLIPBOARD_H
#define _CLIPBOARD_H

#include <QtGui>
#include "ClipboardMainForm.h"
#include "MyListWidgetItem.h"
#include "TextEdit.h"
#include "changeless/NormalModule.h"

class Clipboard: public QWidget, public NormalModule {
	
	Q_OBJECT
	
public:
	Clipboard(QWidget* parent = nullptr);
	~Clipboard();
	Clipboard(const Clipboard&) = delete;
	Clipboard& operator=(const Clipboard&) = delete;
	virtual void Start(void);
	void AddNewClipboardInfo(void);
    
private:
	// 重绘事件
	void paintEvent(QPaintEvent *); 
    // 防止文本框输入内容位于按钮之下
    void SetSearchLineArea(void) const;
	// 移动窗口
	void mousePressEvent(QMouseEvent* event);
    void mouseReleaseEvent(QMouseEvent* event);
	void mouseMoveEvent(QMouseEvent* event);
	// 关闭事件
	void closeEvent(QCloseEvent* event);

private slots:
    // 显示item内容
	void ShowDetails(QListWidgetItem* item);
    // 隐藏所有item
	void HideAllItems(void) const;
    // 显示所有item
	void ShowAllItems(void) const;
	// 显示搜索栏
	void ShowSearchLine(void);
	// 隐藏搜索栏
	void HideSearchLine(void);
	// 搜索item
	void ItemSearching(void);
	// 返回前一个状态
	void BackFront(void);
	// 关闭窗口
	void CloseWidget(void);
	// 清空所有item
	void ClearAllItem(void);

private:
	Ui::ClipboardMainForm* ui;
	//QList<MyListWidgetItem*> m_itemlist;
	//QList<MyListWidgetItem*> m_founditemlist;
	TextEdit* m_texteditform;
	QClipboard* m_clipboard;
	bool m_searching;
	bool m_searched;
	bool m_bDrag;
	int m_xOffset;
	int m_yOffset;
};

// 显示界面
inline void Clipboard::Start(void) {
	this->show();
	
}

// 显示搜索栏
inline void Clipboard::ShowSearchLine(void) {
	this->m_searching = true;
	ui->m_lineEdit->show();
	ui->m_lineeditsearch->show();
}

// 隐藏搜索栏
inline void Clipboard::HideSearchLine(void) {
    ui->m_lineEdit->hide();
	ui->m_lineeditsearch->hide();
}

// 防止文本框输入内容位于按钮之下
inline void Clipboard::SetSearchLineArea(void) const {
    QMargins margins = ui->m_lineEdit->textMargins();
	ui->m_lineEdit->setTextMargins(margins.left(), margins.top(), ui->m_lineeditsearch->width(), margins.bottom());
	ui->m_lineEdit->setPlaceholderText(QString("Searching"));
}

#endif // _CLIPBOARD_H