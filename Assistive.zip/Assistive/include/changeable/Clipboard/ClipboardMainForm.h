/********************************************************************************
** Form generated from reading UI file 'untitled.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef CLIPBOARDMAINFORM_H
#define CLIPBOARDMAINFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ClipboardMainForm
{
public:
    QListWidget *m_listWidget;
    QPushButton *m_closebutton;
    QPushButton *m_searchbutton;
    QPushButton *m_clearbutton;
    QLineEdit *m_lineEdit;
    QPushButton *m_lineeditsearch;
    QPushButton *m_backbutton;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("Form"));
        Form->resize(400, 600);
        Form->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	max-width: 400px;\n"
"    max-height: 600px;\n"
"	background-color: rgb(68, 68, 68);\n"
"	border-radius: 10px 10px 10px 10px;\n"
"}"));
        m_listWidget = new QListWidget(Form);
        m_listWidget->setObjectName(QString::fromUtf8("m_listWidget"));
        m_listWidget->setGeometry(QRect(70, 0, 330, 600));
        m_listWidget->setStyleSheet(QString::fromUtf8("QListWidget{\n"
"	min-width: 310px;\n"
"	min-height: 600px;\n"
"	border-radius: 0px 10px 10px 0px;\n"
"	background-color: rgb(213, 213, 213);\n"
"}"));
        m_closebutton = new QPushButton(Form);
        m_closebutton->setObjectName(QString::fromUtf8("m_closebutton"));
        m_closebutton->setGeometry(QRect(14, 160, 51, 51));
        m_closebutton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	border-image: url(:/close.png);\n"
"	margin: 10px;\n"
"    border: 2px;\n"
"    padding: 20px;\n"
"	min-with: 40px;\n"
"}\n"
"QPushButton::pressed{\n"
"	border-image: url(:/close_clicked.png);\n"
"}"));
        m_searchbutton = new QPushButton(Form);
        m_searchbutton->setObjectName(QString::fromUtf8("m_searchbutton"));
        m_searchbutton->setGeometry(QRect(10, 10, 51, 51));
        m_searchbutton->setAutoFillBackground(false);
        m_searchbutton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	border-image: url(:/search.png);\n"
"	margin: 10px;\n"
"    border: 2px;\n"
"    padding: 20px;\n"
"}\n"
"QPushButton::pressed{\n"
"	border-image: url(:/search_clicked.png);\n"
"}"));
        m_clearbutton = new QPushButton(Form);
        m_clearbutton->setObjectName(QString::fromUtf8("m_clearbutton"));
        m_clearbutton->setGeometry(QRect(10, 60, 51, 51));
        m_clearbutton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	margin: 10px;\n"
"    border: 2px;\n"
"    padding: 20px;\n"
"	min-with: 40px;\n"
"	border-image: url(:/delete.png);\n"
"}\n"
"QPushButton::pressed{\n"
"	border-image: url(:/delete_clicked.png);\n"
"}"));
        m_lineEdit = new QLineEdit(Form);
        m_lineEdit->setObjectName(QString::fromUtf8("m_lineEdit"));
        m_lineEdit->setGeometry(QRect(70, 10, 331, 31));
        m_lineEdit->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	background-color:rgb(243, 243, 243)\n"
"}"));
        m_lineeditsearch = new QPushButton(Form);
        m_lineeditsearch->setObjectName(QString::fromUtf8("m_lineeditsearch"));
        m_lineeditsearch->setGeometry(QRect(370, 10, 31, 31));
        m_lineeditsearch->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	background-color: rgba(243, 243, 243, 243);\n"
"	\n"
"	border-image: url(:/lineeditsearch.png);\n"
"}"));
        m_backbutton = new QPushButton(Form);
        m_backbutton->setObjectName(QString::fromUtf8("m_backbutton"));
        m_backbutton->setGeometry(QRect(10, 110, 51, 51));
        m_backbutton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	margin: 10px;\n"
"    border: 2px;\n"
"    padding: 20px;\n"
"	min-with: 40px;\n"
"	border-image: url(:/back.png);\n"
"}\n"
"QPushButton::pressed{\n"
"	border-image: url(:/back_clicked.png);\n"
"}"));

        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QApplication::translate("Form", "Form", 0, QApplication::UnicodeUTF8));
        m_closebutton->setText(QString());
        m_searchbutton->setText(QString());
        m_clearbutton->setText(QString());
        m_lineeditsearch->setText(QString());
        m_backbutton->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class ClipboardMainForm: public Ui_ClipboardMainForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // CLIPBOARDMAINFORM_H
