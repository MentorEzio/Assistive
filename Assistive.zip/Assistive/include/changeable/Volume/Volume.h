#ifndef _VOLUME_H
#define _VOLUME_H

#include <QtGui>
#include "VolumeMainForm.h"
#include "changeless/NormalModule.h"

namespace Ui{
	class VolumeForm;
}

class Volume: public QWidget, public NormalModule {

	Q_OBJECT

public:
	explicit Volume(QWidget* parent = nullptr);
	~Volume();
	void Start(void);
	virtual void Hide(void);

private:
	void paintEvent(QPaintEvent *);
	void focusOutEvent(QFocusEvent* event);
	int SetVolumeLevel(int level);
	void SetVolumeInitState(void);
	void SetIcon(void);
#if 0
	void keyPressEvent ( QKeyEvent * event );
	void VolumeUp(void);
	void VolumeDown(void);
#endif 

private slots:
	void ChangeVolumeLevel(int level);
	void SetSilent(void);
	
private:
	Ui::VolumeForm* ui;
	int m_isSilent;
	int m_whichicon;
};

inline void Volume::Hide(void) {
	this->hide();
}

#endif // _VOLUME_H