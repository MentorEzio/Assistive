/********************************************************************************
** Form generated from reading UI file 'untitled.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef VOLUMEMAINFORM_H
#define VOLUMEMAINFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_VolumeForm
{
public:
    QSlider *m_volumelslider;
    QPushButton *m_volumeButton;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("Form"));
        Form->resize(178, 178);
        Form->setAutoFillBackground(false);
        Form->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	\n"
"	border-radius: 13px 13px 13px 13px;\n"
"	background-color: rgba(133, 133, 133, 230)\n"
"}"));
        m_volumelslider = new QSlider(Form);
        m_volumelslider->setObjectName(QString::fromUtf8("m_volumelslider"));
        m_volumelslider->setGeometry(QRect(14, 135, 150, 30));
        m_volumelslider->setStyleSheet(QString::fromUtf8("QSlider{\n"
"	border-color: #bcbcbc;\n"
"	\n"
"	background-color: rgba(83, 83, 83, 0);\n"
"}\n"
"QSlider::groove:horizontal {                                \n"
"    border: 1px solid #999999;                             \n"
"    height: 5px;\n"
"    margin: 0px 0;                                         \n"
"    left: 5px; right: 5px; \n"
"}\n"
"QSlider::handle:horizontal {                               \n"
"    border: 0px ;                            \n"
"	border-image: url(:/slider_handle.png);\n"
"    width: 15px;                                           \n"
"    margin: -7px -7px -7px -7px;                  \n"
"}\n"
"QSlider::add-page:horizontal{\n"
"	background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 #bcbcbc, stop:0.25 #bcbcbc, stop:0.5 #bcbcbc, stop:1 #bcbcbc); \n"
"\n"
"}\n"
"QSlider::sub-page:horizontal{                               \n"
" background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 #439cf3, stop:0.25 #439cf3, stop:0.5 #439cf3, stop:1 #439cf3);     "
                        "                \n"
"}\n"
"\n"
""));
        m_volumelslider->setOrientation(Qt::Horizontal);
        m_volumeButton = new QPushButton(Form);
        m_volumeButton->setObjectName(QString::fromUtf8("pushButton"));
        m_volumeButton->setGeometry(QRect(20, 20, 138, 128));
        m_volumeButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	margin: 10px;\n"
"	border: 2px;\n"
"	padding: 20;\n"
"	min-with: 40px;\n"
"	border-image: url(:/volume.png);\n"
"	background-color: rgba(83, 83, 83, 0);\n"
"}\n"
));
        m_volumeButton->setAutoDefault(false);
        m_volumeButton->setDefault(false);
        m_volumeButton->setFlat(false);

        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QApplication::translate("Form", "Form", 0, QApplication::UnicodeUTF8));
        m_volumeButton->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class VolumeForm: public Ui_VolumeForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // VOLUMEMAINFORM_H
