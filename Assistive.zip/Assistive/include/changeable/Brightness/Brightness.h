#ifndef _BRIGHTNESS_H
#define _BRIGHTNESS_H

#include <QtGui>
#include "BrightnessMainForm.h"
#include "changeless/NormalModule.h"

namespace Ui{
	class BrightnessForm;
}

class Brightness: public QWidget, public NormalModule {

	Q_OBJECT

public:
	explicit Brightness(QWidget* parent = nullptr);
	~Brightness();
	void Start(void);
	virtual void Hide(void);

private:
	void paintEvent(QPaintEvent *);
	void focusOutEvent(QFocusEvent* event);
	void SetIcon(void);

private slots:
	void SetBrightLevel(int level);
	
private:
	Ui::BrightnessForm* ui;
	int m_whichicon;
};

inline void Brightness::Hide(void) {
	this->hide();
}


#endif // _BRIGHTNESS_H