/********************************************************************************
** Form generated from reading UI file 'untitled.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef BRIGHTNESSMAINFORM_H
#define BRIGHTNESSMAINFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BrightnessForm
{
public:
    QSlider *m_brightlslider;
    QPushButton *m_brightButton;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("Form"));
        Form->resize(178, 178);
        Form->setAutoFillBackground(false);
        Form->setStyleSheet(QString::fromUtf8("QWidget{\n"
"	\n"
"	border-radius: 13px 13px 13px 13px;\n"
"	background-color: rgba(133, 133, 133, 230)\n"
"}"));
        m_brightlslider = new QSlider(Form);
        m_brightlslider->setObjectName(QString::fromUtf8("m_brightlslider"));
        m_brightlslider->setGeometry(QRect(14, 135, 150, 30));
        m_brightlslider->setStyleSheet(QString::fromUtf8("QSlider{\n"
"	border-color: #bcbcbc;\n"
"	\n"
"	background-color: rgba(83, 83, 83, 0);\n"
"}\n"
"QSlider::groove:horizontal {                                \n"
"    border: 1px solid #999999;                             \n"
"    height: 5px;\n"
"    margin: 0px 0;                                         \n"
"    left: 5px; right: 5px; \n"
"}\n"
"QSlider::handle:horizontal {                               \n"
"    border: 0px ;                            \n"
"	border-image: url(:/slider_handle.png);\n"
"    width: 15px;                                           \n"
"    margin: -7px -7px -7px -7px;                  \n"
"}\n"
"QSlider::add-page:horizontal{\n"
"	background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 #bcbcbc, stop:0.25 #bcbcbc, stop:0.5 #bcbcbc, stop:1 #bcbcbc); \n"
"\n"
"}\n"
"QSlider::sub-page:horizontal{                               \n"
" background: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 #439cf3, stop:0.25 #439cf3, stop:0.5 #439cf3, stop:1 #439cf3);     "
                        "                \n"
"}\n"
"\n"
""));
        m_brightlslider->setOrientation(Qt::Horizontal);
        m_brightButton = new QPushButton(Form);
        m_brightButton->setObjectName(QString::fromUtf8("m_brightButton"));
        m_brightButton->setGeometry(QRect(20, 20, 138, 128));
        m_brightButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	margin: 10px;\n"
"	border: 2px;\n"
"	padding: 20;\n"
"	min-with: 40px;\n"
"	border-image: url(:/bright02.png);\n"
"	background-color: rgba(83, 83, 83, 0);\n"
"}\n"
));
        m_brightButton->setAutoDefault(false);
        m_brightButton->setDefault(false);
        m_brightButton->setFlat(false);

        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QApplication::translate("Form", "Form", 0, QApplication::UnicodeUTF8));
        m_brightButton->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class BrightnessForm: public Ui_BrightnessForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // BRIGHTNESSMAINFORM_H
