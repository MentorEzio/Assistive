#ifndef _NORMALMAINFORM_H
#define _NORMALMAINFORM_H

#include "changeless/MainForm.h"
#include "changeable/HomeMainForm.h"

#include <QtGui>
#include <list>
using namespace std;

namespace Ui {
class Form;
}

class NormalMainForm: public QDialog, public MainForm {
	
	Q_OBJECT
	
public:
	explicit NormalMainForm(QWidget* parent = 0);
	~NormalMainForm();
	virtual void Show(void);
	void HideAllTools(void);
	void ShowNormalMainForm(void);
	virtual void ToolsGetHomeMainForm(void);

private:
	void paintEvent(QPaintEvent *);
	void SetSystemTrayIcon(void);
	void mousePressEvent(QMouseEvent* event); 
	void SetToolsPos(void);
	void SetToolsPosOnCircle(int globX, int globY, int x = 0, int y = 0);

private slots:
	void ShowHomeMainForm(void);
	void RetuentoDesktop(void);
	void ShowClipboard(void);
	void OnExit(void);
	void ShowVolumeCtrl(void);
	void ShowBrightCtrl(void);
	
private:
	Ui::Form* ui;
	HomeMainForm m_home;
	QSystemTrayIcon m_systray;
	list<QPushButton*> m_tools;
};


#endif // _NORMALMAINFORM_H
