#ifndef _FUNCTIONMODULE_H
#define _FUNCTIONMODULE_H

#include <vector>
using namespace std;
#include "changeable/HomeMainForm.h"


class FunctionModule {
public:
	virtual ~FunctionModule() { }

	// 子功能启动的接口规范
	virtual void Start(void) = 0;

	virtual void Hide(void) { }

	void GetHomeMainForm(HomeMainForm* hmf);

protected:
	HomeMainForm* m_homemainform;
};

inline void FunctionModule::GetHomeMainForm(HomeMainForm* hmf) {
	m_homemainform = hmf;
}

#endif // _FUNCTIONMODULE_H
