#ifndef _NORMALMODULEFACTORY_H
#define _NORMALMODULEFACTORY_H

#include "changeless/FunctionModuleFactory.h"

class NormalModuleFactory: public FunctionModuleFactory {
public:
	// 创建功能模块的接口规范
	// 注意：(1) 默认前5个功能为默认功能，启动时会自动开启，如要修改默认功能数量
	//          到Config.h文件中修改DefauleToolsNum
	// 		(2) CreateFunctionModule函数在往vector中加入功能时请使用new的
	//		    方式，并且务必保证前DefauleToolsNum-1个功能为需要默认启动的
	//          功能
	virtual vector<FunctionModule*>* CreateFunctionModule(void);
};

#endif // _NORMALMODULEFACTORY_H
