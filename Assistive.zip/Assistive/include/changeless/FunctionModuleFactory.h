#ifndef _FUNCTIONMODULEFACTORY_H
#define _FUNCTIONMODULEFACTORY_H

#include <vector>
using namespace std;
#include "changeable/Config.h"
#include "debug/debuger.h"

class FunctionModule;

class FunctionModuleFactory {
public:
	FunctionModuleFactory();
	virtual ~FunctionModuleFactory() { }

	// 把新增加的功能加入vector
	void AddNewTools(FunctionModule* newtools);

	// 创建功能模块的接口规范
	virtual vector<FunctionModule*>* CreateFunctionModule(void) = 0;

protected:
	vector<FunctionModule*> m_module;
};

inline FunctionModuleFactory::FunctionModuleFactory() {
	DEBUG_NORMAL("开始预留vector m_module空间\n");

	m_module.reserve(defauleReserveSpace);

	DEBUG_NORMAL("预留vector m_module空间成功\n");
}

// 把新增加的功能加入vector
inline void FunctionModuleFactory::AddNewTools(FunctionModule* newtools) {
	DEBUG_NORMAL("开始增加新功能\n");

	m_module.push_back(newtools);

	DEBUG_NORMAL("增加新功能成功\n");
}

#endif // _FUNCTIONMODULEFACTORY_H
