#ifndef _DEVELOPMODULE_H
#define _DEVELOPMODULE_H

#include "changeless/FunctionModule.h"

class DevelopModule: public FunctionModule {
		
};

#endif // _DEVELOPMODULE_H
