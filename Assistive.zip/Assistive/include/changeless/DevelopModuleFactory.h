#ifndef _DEVELOPMODULEFACTORY_H
#define _DEVELOPMODULEFACTORY_H

#include "changeless/FunctionModuleFactory.h"
#include "changeless/NormalModuleFactory.h"
#include "debug/debuger.h"

class DevelopModuleFactory: public FunctionModuleFactory {
public:
	DevelopModuleFactory();
	// 创建功能模块的接口规范
	// 注意：(1) 默认前5个功能为默认功能，启动时会自动开启，如要修改默认功能数量
	//          到Config.h文件中修改DefauleToolsNum
	// 		(2) CreateFunctionModule函数在往vector中加入功能时请使用new的
	//		    方式，并且务必保证前DefauleToolsNum-1个功能为需要默认启动的
	//          功能
	virtual vector<FunctionModule*>* CreateFunctionModule(void);

private:
	vector<FunctionModule*>* m_pnormalmodule;

};

inline DevelopModuleFactory::DevelopModuleFactory() {
	DEBUG_NORMAL("开始构造DevelopModuleFactory\n");

	m_pnormalmodule = NormalModuleFactory().CreateFunctionModule();
	m_module.swap(*m_pnormalmodule);
	m_pnormalmodule->clear();

	DEBUG_NORMAL("构造DevelopModuleFactory成功\n");
}

#endif // _DEVELOPMODULEFACTORY_H
