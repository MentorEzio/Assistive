#ifndef _ASSISTIVETOUCH_H
#define _ASSISTIVETOUCH_H

#include <vector>
using namespace std;

#include "changeless/Frame.h"
#include "changeless/MainForm.h"
#include "changeless/FunctionModule.h"
#include "changeless/FunctionModuleFactory.h"
#include "changeable/Config.h"
#include "changeable/WinApplication/WinApplication.h"
#include "debug/debuger.h"



class AssistiveTouch: public Frame {
public:
	AssistiveTouch(FunctionModuleFactory& funmodfactory, MainForm& mainform);
	~AssistiveTouch();

	// 启动默认功能
	virtual void StartDefaultTools(void);

	// 启动主界面
	virtual void MainFormInit(void);

private:
	vector<FunctionModule*>* m_functionmodule;
	MainForm*				 m_mainform;
public:
	static WinApplication app;
};



inline AssistiveTouch::AssistiveTouch(FunctionModuleFactory& funmodfactory, MainForm& mainform)
	: m_functionmodule(funmodfactory.CreateFunctionModule()),
	  m_mainform(&mainform) {
	DEBUG_NORMAL("开始让mainform得到funmod\n");

	// 得到功能模块
	m_mainform->GetFunctionModule(m_functionmodule);
	// 功能模块得到home界面
	m_mainform->ToolsGetHomeMainForm();
	
	// 让WinApplication得到剪贴板
	app.GetClipboard((*m_functionmodule)[2]);

	DEBUG_NORMAL("mainform得到funmod成功\n");
}

inline AssistiveTouch::~AssistiveTouch() {
	DEBUG_NORMAL("开始执行~AssistiveTouch()\n");

	for (auto iter : *m_functionmodule) {
		if (nullptr != iter) {
			delete iter;
		}
	}

	DEBUG_NORMAL("执行~AssistiveTouch()成功\n");
}

// 启动主界面
inline void AssistiveTouch::MainFormInit(void) {
	DEBUG_NORMAL("开始启动主界面\n");

	m_mainform->Show();

	DEBUG_NORMAL("启动主界面成功\n");
}

// 启动默认功能
inline void AssistiveTouch::StartDefaultTools(void) {
	DEBUG_NORMAL("开始启动默认功能\n");

	for(int i = 0; i < defauleToolsNum; ++i) {
		(*m_functionmodule)[i]->Start();
	}

	DEBUG_NORMAL("启动默认功能成功\n");
}

#endif // _ASSISTIVETOUCH_H
