#ifndef _NORMALMODULE_H
#define _NORMALMODULE_H

#include "changeless/FunctionModule.h"

class NormalModule: public FunctionModule {
	
};

#endif // _NORMALMODULE_H
