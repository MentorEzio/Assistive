#ifndef _FRAME_H
#define _FRAME_H

class Frame {
public:
	void Init(void);

protected:
	// 启动默认功能
	virtual void StartDefaultTools(void) = 0;
	// 启动界面
	virtual void MainFormInit(void) = 0;

private:
	// 读取配置文件
	void ReadConfigFile(void);
	// 加载动态库
	void LoadDLL(void);
	// 将进程变成守护进程
	void CreateDaemon(void);
	// 注册退出函数
	void RegisterExitFunction(void);

private:
	// 存储配置信息
	// 等填坑
};

#endif // _FRAME_H
