#ifndef _DEBUGER_H
#define _DEBUGER_H

#define DEBUGER

#include <cstdio>

extern FILE* file;

#if defined(DEBUGER)
#define DEBUG_NORMAL(...) 	fprintf(file, " Debug(%s, %s(), %d): ", __FILE__, __FUNCTION__, __LINE__);\
								fprintf(file, __VA_ARGS__)
#define DEBUG_PERROR(...) 	fprintf(file, " Debug(%s, %s(), %d): ", __FILE__, __FUNCTION__, __LINE__);\
								perror(__VA_ARGS__)
#else
#define DEBUG_NORMAL(...)
#define DEBUG_PERROR(...)
#endif

#endif // _DEBUGER_H
