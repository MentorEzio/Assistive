#include "changeless/AssistiveTouch.h"
#include "changeable/NormalMainForm.h"
#include "changeless/NormalModuleFactory.h"


struct DLLConfig;
int argc;
char** argv;
HWND hwndClipBoardViewer;

DLLConfig* dllManager = NULL;

#if defined(DEBUGER)
#include <cstdio>
#include <cstdlib>
FILE* file;
#endif

// �������Ƿ��һ������
static void CheckFirstRunning(void);

void __attribute__((constructor)) GetArgcArgv(int Argc, char* Argv[]) {
	argc = Argc;
	argv = Argv;
}

WinApplication AssistiveTouch::app(argc, argv);

int main(void) {

#if defined(DEBUGER)
	file = fopen("debug.txt", "w+");
#endif

	//CheckFirstRunning();
	//__asm__ __volatile__("": : :"memory");
	// ��׼���ܴ���
	NormalModuleFactory mod;
	// ���洴��
	NormalMainForm mainform;
	
	AssistiveTouch assistivetouch(mod, mainform);

	assistivetouch.Init();

	return AssistiveTouch::app.exec();
}


static void CheckFirstRunning(void) {
#if 0
	HWND hwnd = FindWindow(NULL, L"AssistiveTouch");
	if (NULL != hwnd) {
		exit(0);
	}
	hwndClipBoardViewer = SetClipboardViewer(hwnd);
#endif
}

