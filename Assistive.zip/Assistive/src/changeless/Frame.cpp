//#include <dlfcn.h>
#include "changeless/Frame.h"
#include "debug/debuger.h"
#include "changeable/DLLConfig.h"

extern DLLConfig* dllManager;

void Frame::Init(void) {
	// 读取配置文件
	ReadConfigFile();
	// 加载动态库
	LoadDLL();
	// 将进程变成守护进程
	CreateDaemon();
	// 注册退出函数
	RegisterExitFunction();
	// 启动界面
	MainFormInit();
	// 启动默认功能
	StartDefaultTools();
}

// 读取配置文件
void Frame::ReadConfigFile(void) {
	DEBUG_NORMAL("开始读取配置文件\n");



	DEBUG_NORMAL("读取配置文件成功\n");
}

// 加载动态库
void Frame::LoadDLL(void) {
	DEBUG_NORMAL("开始加载动态库\n");

	dllManager = new DLLConfig;
	dllManager->dllHandle = LoadLibraryEx(TEXT("./bin/dll/libprint.dll"),NULL,LOAD_WITH_ALTERED_SEARCH_PATH);
	dllManager->ModFun1 = (void (*)(void))GetProcAddress(dllManager->dllHandle, "print");
#if 0
	void (*print)(void) = (void (*)(void))GetProcAddress(DLLManager->DLLHandle, "print");
	if(!print) {
		DEBUG_NORMAL("得到dll函数地址失败\n");
		DEBUG_NORMAL("last erron: %d\n", GetLastError());
	}
	print();
#endif
	DEBUG_NORMAL("加载动态库成功\n");
}

// 将进程变成守护进程
void Frame::CreateDaemon(void) {
	DEBUG_NORMAL("开始将进程变成守护进程\n");



	DEBUG_NORMAL("将进程变成守护进程成功\n");
}

// 注册退出函数
void Frame::RegisterExitFunction(void) {
	DEBUG_NORMAL("开始注册退出函数\n");



	DEBUG_NORMAL("注册退出函数成功\n");
}
