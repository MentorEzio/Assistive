#include "changeable/Clipboard/Clipboard.h"
#include "changeable/Clipboard/ClipboardMainForm.h"
#include <windows.h>
#include "changeable/Clipboard/TextEditForm.h"

Clipboard::Clipboard(QWidget* parent): 
	QWidget(parent),
	ui(new Ui::ClipboardMainForm),
	//m_founditemlist(),
	m_texteditform(new TextEdit),
	m_clipboard(QApplication::clipboard()),
	m_searching(false),
	m_searched(false),
	m_bDrag(false),
	m_xOffset(0),m_yOffset(0)
{
	ui->setupUi(this);
	
	// 设置窗口形状
	QBitmap bmp(this->size());
	bmp.fill();
	QPainter p(&bmp);
	p.setPen(Qt::NoPen);
	p.setBrush(Qt::black);
	p.drawRoundedRect(bmp.rect(), 8, 8);
	setMask(bmp);

	// 隐藏垂直方向的滚动条
	ui->m_listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

	// 隐藏搜索栏
	this->HideSearchLine();

	//防止文本框输入内容位于按钮之下
	this->SetSearchLineArea();

	// 设置搜索栏字体大小
	QFont font;
	font.setPointSize(18);
	ui->m_lineEdit->setFont(font);

	// 点击item打开复制内容
	connect(ui->m_listWidget, SIGNAL(itemDoubleClicked(QListWidgetItem*)),
			this, SLOT(ShowDetails(QListWidgetItem*)));
	// 点击搜索按键显示搜索栏
	connect(ui->m_searchbutton, SIGNAL(clicked(void)),
			this, SLOT(ShowSearchLine(void)));
	// 点击搜索栏按键开始搜索
	connect(ui->m_lineeditsearch, SIGNAL(clicked(void)),
			this, SLOT(ItemSearching(void)));
	// 点击返回按键返回前一个状态
	connect(ui->m_backbutton, SIGNAL(clicked(void)),
			this, SLOT(BackFront(void)));
	// 点击关闭按键关闭窗口
	connect(ui->m_closebutton, SIGNAL(clicked(void)),
			this, SLOT(CloseWidget(void)));
	// 点击清理按键清空所有item
	connect(ui->m_clearbutton, SIGNAL(clicked(void)),
			this, SLOT(ClearAllItem(void)));
	
	// 手动添加item
	this->AddNewClipboardInfo();
}

Clipboard::~Clipboard() {
	delete m_texteditform;
	delete ui;
}

// 重绘事件
void Clipboard::paintEvent(QPaintEvent *) {
     QStyleOption opt;
     opt.init(this);
     QPainter p(this);
     style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}

// 隐藏所有item
void Clipboard::HideAllItems(void) const {
	int count = ui->m_listWidget->count();
	for(int i = 0; i < count; ++i) {
		ui->m_listWidget->item(i)->setHidden(true);
	}
}

// 显示所有item
void Clipboard::ShowAllItems(void) const {
	int count = ui->m_listWidget->count();
	for(int i = 0; i < count; ++i) {
		ui->m_listWidget->item(i)->setHidden(false);
	}
}

// 显示item内容
void Clipboard::ShowDetails(QListWidgetItem* item) {
	m_texteditform->show();
	m_texteditform->ShowString(((MyListWidgetItem*)item)->GetString());
}

// 搜索item
void Clipboard::ItemSearching(void) {
	m_searched = true;
	this->HideAllItems();
	QString str = ui->m_lineEdit->text();
	QList<QListWidgetItem*> found_list = ui->m_listWidget->findItems(str, Qt::MatchContains);
	for(auto iter : found_list) {
		iter->setHidden(false);
	}
	this->HideSearchLine();
}


// 返回前一个状态
void Clipboard::BackFront(void) {
	if (m_searching) {
		this->HideSearchLine();
	}
	if (m_searched) {
		this->ShowAllItems();
	}
}

// 关闭窗口
void Clipboard::CloseWidget(void) {
	this->hide();
}

// 清空所有item
void Clipboard::ClearAllItem(void) {
	ui->m_listWidget->clear();
}

// 从剪贴板得到信息并添加item
void Clipboard::AddNewClipboardInfo(void) {
	static QString per;
	static QString orig;
	orig = m_clipboard->text();
	if (per != orig) {
		QListWidgetItem* listitem = new MyListWidgetItem(orig);
		ui->m_listWidget->insertItem(0, listitem);
		per = orig;
	}
}

void Clipboard::mousePressEvent(QMouseEvent* event) {
	m_xOffset = event->globalX() - this->pos().rx();
	m_yOffset = event->globalY() - this->pos().ry();

	if(event->button() == Qt::LeftButton) {
		m_bDrag = true;
	}
}
void Clipboard::mouseReleaseEvent(QMouseEvent* event) {
	if(event->button() == Qt::LeftButton) {
		m_bDrag = false;
	}
}
void Clipboard::mouseMoveEvent(QMouseEvent* event) {
	if(m_bDrag) {
		this->move(event->globalX() - m_xOffset, event->globalY() - m_yOffset);
	}
}

void Clipboard::closeEvent(QCloseEvent* event) {
	event->ignore();
	this->hide();
}