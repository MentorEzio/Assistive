#include "changeable/Clipboard/MyListWidgetItem.h"

QFont MyListWidgetItem::m_itemfont;

MyListWidgetItem::MyListWidgetItem(const QString& str, QListWidget* parent) :
    QListWidgetItem(QIcon("icon/copy.png"), str, parent),
    m_clipboarddetail(new QString(str))
{
    // 设置item字体大小
    m_itemfont.setPointSize(18);
    this->setFont(m_itemfont);
    // 设置item大小
    this->setSizeHint(QSize(330, 40));
}

MyListWidgetItem::~MyListWidgetItem() {
    delete m_clipboarddetail;
}

QString& MyListWidgetItem::GetString(void) {
    return *m_clipboarddetail;
}