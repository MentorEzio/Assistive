#include "changeable/Clipboard/TextEdit.h"
#include "changeable/Clipboard/TextEditForm.h"

TextEdit::TextEdit(QWidget* parent) :
    QWidget(parent),
    ui(new Ui::TextEditForm)
{
    ui->setupUi(this);
    ui->m_textEdit->setFontPointSize(20);
}

TextEdit::~TextEdit() {
    delete ui;
}

void TextEdit::ShowString(QString& str) const {
    ui->m_textEdit->clear();
    ui->m_textEdit->insertPlainText(str);
}

void TextEdit::closeEvent(QCloseEvent* event) {
	event->ignore();
	this->hide();
}
