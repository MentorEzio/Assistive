#include "changeable/Brightness/Brightness.h"
#include <windows.h>
#include <mmdeviceapi.h> 	
#include <endpointvolume.h>
#include <audioclient.h>
#include <objbase.h>

Brightness::Brightness(QWidget* parent) :
	QWidget(parent),
	ui(new Ui::BrightnessForm),
	m_whichicon(2)
{
	ui->setupUi(this);
	
	this->setWindowFlags(Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint | Qt::Tool);

	this->setAttribute(Qt::WA_TranslucentBackground); 
	
	ui->m_brightlslider->setRange(0, 100);
	
	ui->m_brightlslider->setValue(50);

	connect(ui->m_brightlslider, SIGNAL(valueChanged(int)),
			this, SLOT(SetBrightLevel(int)));
	connect(ui->m_brightlslider, SIGNAL(sliderReleased(void)),
			this, SLOT(setFocus(void)));
	connect(ui->m_brightButton, SIGNAL(released(void)),
			this, SLOT(setFocus(void)));
}

Brightness::~Brightness() {
	delete ui;
}

void Brightness::Start(void) {
	QMouseEvent mouseEvent(QEvent::None, QPoint(), Qt::NoButton, Qt::NoButton, Qt::NoModifier);

	int globX = mouseEvent.globalX();
	int globY = mouseEvent.globalY();
	int desktopwidth = QApplication::desktop()->width();
	int desktophigh = QApplication::desktop()->height();

	int minx = globX - 89;
	int miny = globY - 89;
	int maxx = globX + 178;
	int maxy = globY + 178;

	// 左上角
	if (minx < 0 && miny < 0) {
		this->move(0, 0);
		goto SHOW;
	}

	// 最左边
	if (minx < 0 && miny > 0 && maxy < desktophigh) {
		this->move(0, miny);
		goto SHOW;
	}

	// 左下角
	if (minx < 0 && maxy > desktophigh) {
		this->move(0, desktophigh - 220);
		goto SHOW;
	}

	// 最顶部
	if (miny < 0 && minx > 0 && maxx < desktopwidth) {
		this->move(globX, 0);
		goto SHOW;
	}

	// 最底部
	if (maxy > desktophigh && minx > 0 && maxx < desktopwidth) {
		this->move(globX, desktophigh - 220);
		goto SHOW;
	}

	// 右上角
	if (maxx > desktopwidth && miny < 0) {
		this->move(desktopwidth - 178, 0);
		goto SHOW;
	}

	// 最右边
	if (maxx > desktopwidth && miny > 0 && maxy < desktophigh) {
		this->move(desktopwidth - 178, globY);
		goto SHOW;
	}

	// 右下角
	if (maxx > desktopwidth && maxy > desktophigh) {
		this->move(desktopwidth - 178, desktophigh - 220);
		goto SHOW;
	}

	this->move(globX - 89, globY - 89);

SHOW:
	this->show();
	this->setFocus();
	this->activateWindow();
}

void Brightness::SetIcon(void) {
	switch(m_whichicon) {
		case 0:
			ui->m_brightButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
											"	margin: 10px;\n"
											"	border: 2px;\n"
											"	padding: 20;\n"
											"	min-with: 40px;\n"
											"	border-image: url(:/bright00.png);\n"
											"	background-color: rgba(83, 83, 83, 0);\n"
											"}\n"));
			break;
		case 1:
			ui->m_brightButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
											"	margin: 10px;\n"
											"	border: 2px;\n"
											"	padding: 20;\n"
											"	min-with: 40px;\n"
											"	border-image: url(:/bright01.png);\n"
											"	background-color: rgba(83, 83, 83, 0);\n"
											"}\n"));
			break;
		case 2:
			ui->m_brightButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
											"	margin: 10px;\n"
											"	border: 2px;\n"
											"	padding: 20;\n"
											"	min-with: 40px;\n"
											"	border-image: url(:/bright02.png);\n"
											"	background-color: rgba(83, 83, 83, 0);\n"
											"}\n"));
			break;
		case 3:
			ui->m_brightButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
											"	margin: 10px;\n"
											"	border: 2px;\n"
											"	padding: 20;\n"
											"	min-with: 40px;\n"
											"	border-image: url(:/bright03.png);\n"
											"	background-color: rgba(83, 83, 83, 0);\n"
											"}\n"));
			break;
		case 4:
		case 5:
			ui->m_brightButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
											"	margin: 10px;\n"
											"	border: 2px;\n"
											"	padding: 20;\n"
											"	min-with: 40px;\n"
											"	border-image: url(:/bright04.png);\n"
											"	background-color: rgba(83, 83, 83, 0);\n"
											"}\n"));
			break;
		default:
			break;
	}
}

// 重绘事件
void Brightness::paintEvent(QPaintEvent *) {
     QStyleOption opt;
     opt.init(this);
     QPainter p(this);
     style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}

// 设置伽马值
void Brightness::SetBrightLevel(int level) {
	m_whichicon = level / 20;
	void *lpGamma=NULL;
	int iArrayValue;
	WORD gMap[3][256]={0};
	lpGamma=&gMap;
	HDC hdc=GetDC(NULL);
	
	for (int i = 0;i < 256;++i)
	{
		iArrayValue=i*(level*2+128);
		if(iArrayValue>65535)
		{
			iArrayValue=65535;
		}
		gMap[0][i]=(WORD)iArrayValue;
		gMap[1][i]=(WORD)iArrayValue;
		gMap[2][i]=(WORD)iArrayValue;
	}

	SetDeviceGammaRamp(hdc,lpGamma);
	static int i = m_whichicon;
	if (i != m_whichicon) {
		this->SetIcon();
		i = m_whichicon;
	}
	
}

void Brightness::focusOutEvent(QFocusEvent* event) {
	if (event->lostFocus() && !ui->m_brightlslider->hasFocus() && !ui->m_brightButton->hasFocus()) {
		this->hide();
		m_homemainform->Show();
	}
}