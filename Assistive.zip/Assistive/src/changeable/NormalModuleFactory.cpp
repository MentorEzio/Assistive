#include "changeless/NormalModuleFactory.h"
#include "changeable/DebugTool/DebugTool.h"
#include "changeable/BacktoDesktop/BacktoDesktop.h"
#include "changeable/Clipboard/Clipboard.h"
#include "changeable/Volume/Volume.h"
#include "changeable/Brightness/Brightness.h"
#include "debug/debuger.h"

vector<FunctionModule*>* NormalModuleFactory::CreateFunctionModule(void) {
	DEBUG_NORMAL("开始创建NormalModule\n");

	// 创建新功能如下：
	// AddNewTools(new Tools);
	AddNewTools(new DebugTool);
	AddNewTools(new BacktoDesktop);
	AddNewTools(new Clipboard);
	AddNewTools(new Volume);
	AddNewTools(new Brightness);

	DEBUG_NORMAL("创建NormalModule成功\n");

	return &m_module;
}
