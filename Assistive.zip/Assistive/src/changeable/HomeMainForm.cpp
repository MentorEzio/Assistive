#include "changeable/HomeMainForm.h"
#include "changeable/NormalMainForm.h"
#include "changeable/DebugHomeMainForm.h"


#include <QtGui>

#include "debug/debuger.h"
#include <cstdio>

#include <windows.h>

//static void SetIcon(QPushButton* pushbutton, char* path, int iconW, int iconH);

HomeMainForm::HomeMainForm(NormalMainForm* nMF, QWidget* parent) :
	QDialog(parent),
	ui(new Ui::HomeForm),
	m_normalMainForm(nMF),
	m_timer(new QTimer(this)),
	m_bDrag(false),
	m_xOffset(0),m_yOffset(0),
	m_cx(GetSystemMetrics(SM_CXSCREEN)), 
	m_cy(GetSystemMetrics(SM_CYSCREEN)) 
{
	DEBUG_NORMAL("homemainform ctor\n");

	ui->setupUi(this);
	// ���ô�����״
	QBitmap bmp(this->size());
	bmp.fill();
	QPainter p(&bmp);
	p.setPen(Qt::NoPen);
	p.setBrush(Qt::black);
	p.drawRoundedRect(bmp.rect(), 20, 20);
	setMask(bmp);

	setWindowFlags(Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint | Qt::Tool);

	m_timer->setSingleShot(true);

	DEBUG_NORMAL("homemainform ctor end\n");
}

HomeMainForm::~HomeMainForm() {
	delete ui;
	delete m_timer;
}

// qtdesigner ���ͼƬ��Ҫ��дpaintEvent�¼� �ֲ��ϵĺ����ճ�����
void HomeMainForm::paintEvent(QPaintEvent *) {
     QStyleOption opt;
     opt.init(this);
     QPainter p(this);
     style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}

void HomeMainForm::mousePressEvent(QMouseEvent* event) {
	this->m_xOffset = event->globalX() - this->pos().rx();
	this->m_yOffset = event->globalY() - this->pos().ry();
	m_timer->start(1000);
	if(event->button() == Qt::LeftButton) {
		this->m_bDrag = true;
	}
}

void HomeMainForm::mouseReleaseEvent(QMouseEvent* event) {
	if(event->button() == Qt::LeftButton && m_timer->isActive()) {
		m_timer->stop();
		this->m_bDrag = false;
		this->ShowNormalMainForm();
	} else {
		this->m_bDrag = false;
	}
}

void HomeMainForm::mouseMoveEvent(QMouseEvent* event) {
	int mouseX = event->globalX();
	int mouseY = event->globalY();
	int minsX = mouseX - this->m_xOffset;
	int minsY = mouseY - this->m_yOffset;
	int addX = mouseX + (65 - this->m_xOffset);
	int addY = mouseY + (65 - this->m_yOffset);
	
	if(m_timer->isActive()) {
		m_timer->stop();
	} else {
		// ��һ������
	}
	
    if(m_bDrag) {
		if (minsX <= 0 && minsY <= 0)
			this->move(0, 0);
		else if (addX >= m_cx && minsY <= 0)
			this->move(m_cx - 65, 0);
		else if (minsX <= 0 && addY >= m_cy)
			this->move(0, m_cy - 65);
		else if (addX >= m_cx && addY >= m_cy)
			this->move(m_cx - 65, m_cy - 65);
		else if (minsX <= 0)
			this->move(0, minsY);
		else if (addX >= m_cx)
			this->move(m_cx - 65, minsY);
		else if (minsY <= 0)
			this->move(minsX, 0);
		else if (addY >= m_cy)
			this->move(minsX, m_cy - 65);
		else
			this->move(minsX, minsY);
    }
}

void HomeMainForm::Show(void) {
	// ���ô��������ö�, �ޱ߿�������������ʾ
	this->show();
}

void HomeMainForm::ShowNormalMainForm(void) {
	m_normalMainForm->HideAllTools();
	this->hide();
	m_normalMainForm->ShowNormalMainForm();
}

#if 0
static void SetIcon(QPushButton* pushbutton, char* path, int iconW, int iconH) {
	QIcon icon;
	icon.addFile(path);
	pushbutton->setIcon(icon);
	pushbutton->setIconSize(QSize(iconW, iconH));
	pushbutton->setStyleSheet("border-style: flat");
}
#endif
