#include "changeable/Volume/Volume.h"
#include <windows.h>
#include <mmdeviceapi.h> 	
#include <endpointvolume.h>
#include <audioclient.h>
#include <objbase.h>


Volume::Volume(QWidget* parent) :
	QWidget(parent),
	ui(new Ui::VolumeForm),
	m_isSilent(false)
{
	CoInitialize(0);
	
	ui->setupUi(this);
	
	setWindowFlags(Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint | Qt::Tool);

	setAttribute(Qt::WA_TranslucentBackground); 
	
	ui->m_volumelslider->setRange(0, 100);

	connect(ui->m_volumelslider, SIGNAL(valueChanged(int)),
			this, SLOT(ChangeVolumeLevel(int)));
	connect(ui->m_volumeButton, SIGNAL(clicked(void)),
			this, SLOT(SetSilent(void)));
	connect(ui->m_volumelslider, SIGNAL(sliderReleased(void)),
			this, SLOT(setFocus(void)));
	connect(ui->m_volumeButton, SIGNAL(released(void)),
			this, SLOT(setFocus(void)));
}

Volume::~Volume() {
	delete ui;
	CoUninitialize();
}

void Volume::SetVolumeInitState(void) {
	this->SetVolumeLevel(-4);
	int temp = m_isSilent;
	ui->m_volumelslider->setValue(SetVolumeLevel(-3));
	if (1 == temp) {
		this->SetVolumeLevel(-1);
	}
	this->SetIcon();
}

void Volume::Start(void) {
	this->SetVolumeInitState();
	QMouseEvent mouseEvent(QEvent::None, QPoint(), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
	int globX = mouseEvent.globalX();
	int globY = mouseEvent.globalY();
	int desktopwidth = QApplication::desktop()->width();
	int desktophigh = QApplication::desktop()->height();

	int minx = globX - 89;
	int miny = globY - 89;
	int maxx = globX + 178;
	int maxy = globY + 178;

	// 左上角
	if (minx < 0 && miny < 0) {
		this->move(0, 0);
		goto SHOW;
	}

	// 最左边
	if (minx < 0 && miny > 0 && maxy < desktophigh) {
		this->move(0, miny);
		goto SHOW;
	}

	// 左下角
	if (minx < 0 && maxy > desktophigh) {
		this->move(0, desktophigh - 220);
		goto SHOW;
	}

	// 最顶部
	if (miny < 0 && minx > 0 && maxx < desktopwidth) {
		this->move(globX, 0);
		goto SHOW;
	}

	// 最底部
	if (maxy > desktophigh && minx > 0 && maxx < desktopwidth) {
		this->move(globX, desktophigh - 220);
		goto SHOW;
	}

	// 右上角
	if (maxx > desktopwidth && miny < 0) {
		this->move(desktopwidth - 178, 0);
		goto SHOW;
	}

	// 最右边
	if (maxx > desktopwidth && miny > 0 && maxy < desktophigh) {
		this->move(desktopwidth - 178, globY);
		goto SHOW;
	}

	// 右下角
	if (maxx > desktopwidth && maxy > desktophigh) {
		this->move(desktopwidth - 178, desktophigh - 220);
		goto SHOW;
	}

	this->move(globX - 89, globY - 89);

SHOW:
	this->show();
	this->setFocus();
	this->activateWindow();
}

void Volume::SetIcon(void) {
	switch(m_whichicon) {
		case 0:
			ui->m_volumeButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
										"	margin: 10px;\n"
										"	border: 2px;\n"
										"	padding: 20;\n"
										"	min-with: 40px;\n"
										"	border-image: url(:/slient.png);\n"
										"	background-color: rgba(83, 83, 83, 0);\n"
										"}\n"
										));
			break;
		case 1:
			ui->m_volumeButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
										"	margin: 10px;\n"
										"	border: 2px;\n"
										"	padding: 20;\n"
										"	min-with: 40px;\n"
										"	border-image: url(:/volume.png);\n"
										"	background-color: rgba(83, 83, 83, 0);\n"
										"}\n"
										));
			break;
		case 2:
			ui->m_volumeButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
										"	margin: 10px;\n"
										"	border: 2px;\n"
										"	padding: 20;\n"
										"	min-with: 40px;\n"
										"	border-image: url(:/volume_zero.png);\n"
										"	background-color: rgba(83, 83, 83, 0);\n"
										"}\n"
										));
			break;
		default:
			break;
	}
}

void Volume::SetSilent(void) {
	if (1 == m_isSilent) {
		this->SetVolumeLevel(-2);
	} else {
		this->SetVolumeLevel(-1);
	}

	this->SetIcon();
}

// 重绘事件
void Volume::paintEvent(QPaintEvent *) {
     QStyleOption opt;
     opt.init(this);
     QPainter p(this);
     style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}

// 改变音量值
void Volume::ChangeVolumeLevel(int level) {
	if (m_isSilent) {
		//this->SetVolumeLevel(-2);
		this->SetSilent();
	}
	
	static int num = m_whichicon;
	this->SetVolumeLevel(level);

	//static int num = m_whichicon;
	if (num != m_whichicon) {
		this->SetIcon();
		num = m_whichicon;
	}
	
	this->setFocus();
}

// -1	 静音
// -2 	 恢复静音
// -3	 得到系统当前音量
// -4 	 得到是否静音
// 0~100 音量比例
int Volume::SetVolumeLevel(int level) {
    HRESULT hr;
    IMMDeviceEnumerator* pDeviceEnumerator=0;
    IMMDevice* pDevice=0;
    IAudioEndpointVolume* pAudioEndpointVolume=0;
    IAudioClient* pAudioClient=0;

    hr = CoCreateInstance(__uuidof(MMDeviceEnumerator),NULL,CLSCTX_ALL,__uuidof(IMMDeviceEnumerator),(void**)&pDeviceEnumerator);

    hr = pDeviceEnumerator->GetDefaultAudioEndpoint(eRender,eMultimedia,&pDevice);

    hr = pDevice->Activate(__uuidof(IAudioEndpointVolume),CLSCTX_ALL,NULL,(void**)&pAudioEndpointVolume);

    hr = pDevice->Activate(__uuidof(IAudioClient),CLSCTX_ALL,NULL,(void**)&pAudioClient);
	
	float value = 0.0f;

	if (-1 == level) {
		hr = pAudioEndpointVolume->SetMute(TRUE,NULL);
		m_isSilent = true;
		m_whichicon = 0;
	} else if (-2 == level) {
		hr = pAudioEndpointVolume->SetMute(FALSE,NULL);
		m_isSilent = false;
		pAudioEndpointVolume->GetMasterVolumeLevelScalar(&value);
		if (0 == (int)(value * 100)) {
			m_whichicon = 2;
		} else {
			m_whichicon = 1;
		}
	} else if (-3 == level) {
		pAudioEndpointVolume->GetMasterVolumeLevelScalar(&value);
	} else if (-4 == level) {
		pAudioEndpointVolume->GetMute((WINBOOL*)&m_isSilent);
		if (1 == m_isSilent) {
			m_whichicon = 0;
		} else {
			pAudioEndpointVolume->GetMasterVolumeLevelScalar(&value);
			if (0 == (int)(value * 100)) {
				m_whichicon = 2;
			} else {
				m_whichicon = 1;
			}
		}
	} else {
		float fVolume = level / 100.0f;
		hr = pAudioEndpointVolume->SetMasterVolumeLevelScalar(fVolume,&GUID_NULL);
		pAudioEndpointVolume->GetMasterVolumeLevelScalar(&value);
		if (0 == (int)(value * 100)) {
			m_whichicon = 2;
		} else {
			m_whichicon = 1;
		}
	}
	
    pAudioClient->Release();
    pAudioEndpointVolume->Release();
	
    pDevice->Release();
    pDeviceEnumerator->Release();

	return (int)(value * 100);
}

void Volume::focusOutEvent(QFocusEvent* event) {
	if (event->lostFocus() && !ui->m_volumelslider->hasFocus() && !ui->m_volumeButton->hasFocus()) {
		this->hide();
		m_homemainform->Show();
	}
}

#if 0

void Volume::VolumeDown(void) {
	keybd_event(VK_VOLUME_DOWN, \
		MapVirtualKey(VK_VOLUME_DOWN, 0), \
		KEYEVENTF_EXTENDEDKEY, 0);

	keybd_event(VK_VOLUME_DOWN, \
		MapVirtualKey(VK_VOLUME_DOWN, 0), \
		KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
}

void Volume::VolumeUp(void) {
	//按下键
	keybd_event(VK_VOLUME_UP,\
		MapVirtualKey(VK_VOLUME_UP, 0), \
		KEYEVENTF_EXTENDEDKEY, 0);
	//松开键
	keybd_event(VK_VOLUME_UP, \
		MapVirtualKey(VK_VOLUME_UP, 0), \
		KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
}

void Volume::keyPressEvent ( QKeyEvent * event ) {
	switch(event->key()) {
		case Qt::Key_Down:
		case Qt::Key_Left:
			VolumeDown();
			break;
		case Qt::Key_Right:
		case Qt::Key_Up:
			VolumeUp();
			break;
		default:
			break;
	}

	ui->m_volumelslider->setValue(SetVolumeLevel(-3));
}

#endif