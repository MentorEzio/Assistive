﻿#include "changeable/NormalMainForm.h"
#include "changeable/DebugMainForm.h"
#include "changeable/Config.h"

#include <QtGui>

#include "debug/debuger.h"
#include <cstdio>

#include <windows.h>

NormalMainForm::NormalMainForm(QWidget* parent) :
	QDialog(parent),
	ui(new Ui::Form),
	m_home(this)
{
	DEBUG_NORMAL("normalmainform ctor\n");

	ui->setupUi(this);

	// 改变widget大小
	this->resize(QApplication::desktop()->width(), QApplication::desktop()->height());

	// 设置隐藏图标
	SetSystemTrayIcon();

	setWindowFlags(Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint | Qt::Tool);

	setAttribute(Qt::WA_TranslucentBackground);

	connect(ui->m_desktopbutton, SIGNAL(clicked()),
			this, SLOT(RetuentoDesktop(void)));
	connect(ui->m_clipboard, SIGNAL(clicked()),
			this, SLOT(ShowClipboard(void)));
	connect(ui->m_volume, SIGNAL(clicked()),
			this, SLOT(ShowVolumeCtrl(void)));
	connect(ui->m_bright, SIGNAL(clicked()),
			this, SLOT(ShowBrightCtrl(void)));

	m_tools.push_back(ui->m_desktopbutton);
	m_tools.push_back(ui->m_clipboard);
	m_tools.push_back(ui->m_volume);
	m_tools.push_back(ui->m_bright);
	m_tools.push_back(ui->m1);
	m_tools.push_back(ui->m2);
	
	m_tools.push_back(ui->m_backbutton);
	

	DEBUG_NORMAL("normalmainform ctor end\n");
}

NormalMainForm::~NormalMainForm() {
	delete ui;
}

void NormalMainForm::ToolsGetHomeMainForm(void) {
	for (auto iter : *m_pfunctionmodule) {
		iter->GetHomeMainForm(&m_home);
	}
}

void NormalMainForm::paintEvent(QPaintEvent *) {
     QStyleOption opt;
     opt.init(this);
     QPainter p(this);
     style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}

void NormalMainForm::ShowNormalMainForm(void) {
	SetToolsPos();
	this->show();
}

void NormalMainForm::SetToolsPos(void) {
	QMouseEvent event(QEvent::None, QPoint(), Qt::NoButton, Qt::NoButton, Qt::NoModifier);
	int globX = event.globalX();
	int globY = event.globalY();
	int desktopwidth = QApplication::desktop()->width();
	int desktophigh = QApplication::desktop()->height();

	int minx = globX - (defauleCircleSize + defaulePushButtonHalfSize);
	int miny = globY - (defauleCircleSize + defaulePushButtonHalfSize);
	int maxx = globX + (defauleCircleSize + defaulePushButtonHalfSize);
	int maxy = globY + (defauleCircleSize + defaulePushButtonHalfSize);

	// 左上角
	if (minx < 0 && miny < 0) {
		this->SetToolsPosOnCircle(globX, globY, -minx, -miny);
		return;
	}
	// 最左边
	if (minx < 0 && miny > 0 && maxy < desktophigh) {
		this->SetToolsPosOnCircle(globX, globY, -minx);
		return;
	}
	// 左下角
	if (minx < 0 && maxy > desktophigh) {
		this->SetToolsPosOnCircle(globX, globY, -minx, -(maxy - desktophigh));
		return;
	}
	// 最顶部
	if (miny < 0 && minx > 0 && maxx < desktopwidth) {
		this->SetToolsPosOnCircle(globX, globY, 0, -miny);
		return;
	}
	// 最底部
	if (maxy > desktophigh && minx > 0 && maxx < desktopwidth) {
		this->SetToolsPosOnCircle(globX, globY, 0, -(maxy - desktophigh));
		return;
	}
	// 右上角
	if (maxx > desktopwidth && miny < 0) {
		this->SetToolsPosOnCircle(globX, globY, -(maxx - desktopwidth), -miny);
		return;
	}
	// 最右边
	if (maxx > desktopwidth && miny > 0 && maxy < desktophigh) {
		this->SetToolsPosOnCircle(globX, globY, -(maxx - desktopwidth));
		return;
	}
	// 右下角
	if (maxx > desktopwidth && maxy > desktophigh) {
		this->SetToolsPosOnCircle(globX, globY, -(maxx - desktopwidth), -(maxy - desktophigh));
		return;
	}

	this->SetToolsPosOnCircle(globX, globY);
	return;

}

void NormalMainForm::SetToolsPosOnCircle(int globX, int globY, int x, int y) {
	int n = 7, i = 0;
	for (auto iter = m_tools.begin(); iter != m_tools.end(); ++i, ++iter) {
		(*iter)->move(globX + defauleCircleSize * cos(2 * 3.141 * (i - 1) / n) - defaulePushButtonHalfSize + x, 
					globY + defauleCircleSize * sin(2 * 3.141 * (i - 1) / n) - defaulePushButtonHalfSize + y) ;		
	}
}

void NormalMainForm::mousePressEvent(QMouseEvent* event) {
	if (event->button() == Qt::LeftButton) {
		this->ShowHomeMainForm();
	}
}

void NormalMainForm::SetSystemTrayIcon(void) {
	// 设置隐藏的图标
	m_systray.setIcon(QIcon(":/home.png"));
	// 设置隐藏的图标的菜单
	QMenu* menu = new QMenu();
	menu->addAction(ui->m_actionExit);
	menu->addSeparator();
	m_systray.setContextMenu(menu);
	// 显示隐藏的图标
	m_systray.show();
	
	connect(ui->m_actionExit, SIGNAL(triggered()),
			this, SLOT(OnExit(void)));
}

void NormalMainForm::Show(void) {
	m_home.Show();
}


void NormalMainForm::ShowHomeMainForm(void) {
	this->hide();
	m_home.show();
}

void NormalMainForm::HideAllTools(void) {
	(*m_pfunctionmodule)[3]->Hide();
	(*m_pfunctionmodule)[4]->Hide();
}

void NormalMainForm::ShowBrightCtrl(void) {
	(*m_pfunctionmodule)[4]->Start();
	this->hide();
}

void NormalMainForm::ShowVolumeCtrl(void) {
	(*m_pfunctionmodule)[3]->Start();
	this->hide();
}

void NormalMainForm::RetuentoDesktop(void) {
	(*m_pfunctionmodule)[1]->Start();
	this->ShowHomeMainForm();
}

void NormalMainForm::ShowClipboard(void) {
	(*m_pfunctionmodule)[2]->Start();
	this->ShowHomeMainForm();
}

void NormalMainForm::OnExit(void) {
	QApplication::exit(0);
}




