#include "changeable/WinApplication/WinApplication.h"

WinApplication::WinApplication(int argc, char *argv[]) :
	QApplication(argc,argv),
	m_clipboard(nullptr)
{  
}   

bool WinApplication::winEventFilter(MSG *msg, long *) {  
	switch (msg->message) {
		// 剪贴板更新
		case WM_DRAWCLIPBOARD:
			// 重绘
			if (nullptr != m_clipboard)
				m_clipboard->AddNewClipboardInfo();
			// 第一个参数是下一个剪贴板监听链的窗口句柄
			SendMessage(hwndClipBoardViewer, msg->message, 
						msg->wParam, msg->lParam);
			break;
		// 当剪贴板监听链节点减少，会收到这条消息
		// 第一个收到这个消息的是最后一个调用GetClipboardViewer()的窗口
		case WM_CHANGECBCHAIN:
			// 如果是本节点的下一个节点移出
			if ((HWND)msg->wParam == hwndClipBoardViewer) {
				hwndClipBoardViewer = (HWND)msg->lParam;
			}
			// 否则向下一个节点传递消息
			else if (hwndClipBoardViewer != NULL) {
				SendMessage(hwndClipBoardViewer, msg->message, 
							msg->wParam, msg->lParam);
			}
			break;
	}
	return false;
}  